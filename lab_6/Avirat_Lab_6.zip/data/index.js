const booksData = require('./books');
const reviewData = require('./reviews');

module.exports = {
    books: booksData,
    reviews: reviewData
};