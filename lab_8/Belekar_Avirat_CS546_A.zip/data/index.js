const shows = require("./shows");
module.exports = {
    shows: shows,
};